<?php
/**
 * @license    MIT
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

require ModuleHelper::getLayoutPath('mod_anirata_calendly', $params->get('layout', 'default'));
